const express = require('express');
const router = express.Router();

router.get('/', (req, res) =>{
    res.render('index');
})

router.post('/subidas', (req, res) => {
    console.log(req.file);
    res.send('uploaded');
});

module.exports = router;

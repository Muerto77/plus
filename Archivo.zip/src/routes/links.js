const express = require('express');
const router = express.Router();

const pool = require('../database');
const { estaLogeado } = require ('../lib/auth');

router.get('/alumnos', estaLogeado, (req, res) => {
    res.render('links/alumnos');
});

router.get('/apoderados', estaLogeado, (req, res) => {
    res.render('links/apoderados');
});

// ALUMNOS
router.post ('/alumnos', estaLogeado, async (req, res) => {
    const {nombre, a_paterno, a_materno, rut, curso, f_nacimiento, pais, sexo, region, comuna, s_previsional, direccion, observaciones} = req.body;
    const id_alumnos ={
        nombre,
        a_paterno,
        a_materno,
        rut,
        curso,
        f_nacimiento,
        pais,
        sexo,
        region,
        comuna,
        s_previsional,
        direccion,
        observaciones,
        alumnos_id: req.user.id
    };
    await pool.query('INSERT INTO alumnos set ?', [id_alumnos]);
    req.flash('success', 'Datos agregados Correctamente');
    res.redirect('/links');
});

router.get ('/', estaLogeado, async (req, res) => {
    const datos = await pool.query('SELECT * FROM alumnos WHERE alumnos_id = ?', [req.user.id]);
    res.render('links/list', { datos });
});


router.get ('/delete/:id', estaLogeado, async (req, res) => {
    const { id } = req.params;
    await pool.query('DELETE FROM alumnos WHERE id_alumnos = ?', [id]);
    req.flash('success', 'Datos Borrados Correctamente');
    res.redirect('/links');
});

router.get ('/edit/:id_alumnos', estaLogeado, async (req, res) => {
    const { id_alumnos } = req.params;
    const links = await pool.query('SELECT * FROM alumnos WHERE id_alumnos = ?', [id_alumnos]);
    res.render('links/edit', {links: links[0]});
});

router.post ('/edit/:id_alumnos', estaLogeado, async (req, res) => {
    const { id_alumnos } = req.params;
    const {nombre, a_paterno, a_materno, rut, curso, f_nacimiento, pais, sexo, region, comuna, s_previsional, direccion, observaciones} = req.body;
    const alumnos = {
        nombre,
        a_paterno,
        a_materno,
        rut,
        curso,
        f_nacimiento,
        pais,
        sexo,
        region,
        comuna,
        s_previsional,
        direccion,
        observaciones
    };
    await pool.query('UPDATE alumnos set ? WHERE id_alumnos = ?', [alumnos, id_alumnos]);
    req.flash('success', 'Datos Editados Correctamente');
    res.redirect('/links');
});

// APODERADOS
router.post ('/apoderados', estaLogeado, async (req, res) => {
    const {nombre, a_paterno, a_materno, rut, sexo, pais, comuna, direccion, t_casa, t_cel, email, t_apoderado, educacion, parentesco, observaciones} = req.body;
    const id_apoderados ={
        nombre,
        a_paterno,
        a_materno,
        rut,
        sexo,
        pais,
        comuna,
        direccion,
        t_casa,
        t_cel,
        email,
        t_apoderado,
        educacion,
        parentesco,
        observaciones,
        apoderados_id: req.user.id
    };
    await pool.query('INSERT INTO apoderados set ?', [id_apoderados]);
    req.flash('success', 'Datos agregados Correctamente');
    res.redirect('/links');
});

router.get ('/', estaLogeado, async (req, res) => {
    const datos_a = await pool.query('SELECT * FROM apoderados WHERE apoderados_id = ?', [req.user.id]);
    res.render('links/list', { datos_a });
});

router.get ('/delete/:id', estaLogeado, async (req, res) => {
    const { id } = req.params;
    await pool.query('DELETE FROM apoderados WHERE id_apoderados = ?', [id]);
    req.flash('success', 'Datos Borrados Correctamente');
    res.redirect('/apoderados');
});

router.get ('/edit/:id_apoderados', estaLogeado, async (req, res) => {
    const { id_apoderados } = req.params;
    const apoderados_id = await pool.query('SELECT * FROM apoderados WHERE id_apoderados = ?', [id_apoderados]);
    res.render('links/edit', {links: links[0]});
});

router.post ('/edit/:id_apoderados', estaLogeado, async (req, res) => {
    const { id_apoderados } = req.params;
    const {nombre, a_paterno, a_materno, rut, sexo, pais, comuna, direccion, t_casa, t_cel, email, t_apoderado, educacion, parentesco, observaciones} = req.body;
    const apoderados = {
        nombre,
        a_paterno,
        a_materno,
        rut,
        sexo,
        pais,
        comuna,
        direccion,
        t_casa,
        t_cel,
        email,
        t_apoderado,
        educacion,
        parentesco,
        observaciones
    };
    await pool.query('UPDATE apoderados set ? WHERE id_apoderados = ?', [apoderados, id_apoderados]);
    req.flash('success', 'Datos Editados Correctamente');
    res.redirect('/links');
});

module.exports = router;
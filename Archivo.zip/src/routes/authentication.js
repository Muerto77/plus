const express = require('express');
const router = express.Router();

const passport = require('passport');
const { estaLogeado, noLogeado } = require ('../lib/auth');

router.get('/signup', noLogeado, (req, res) => {
    res.render('auth/signup');
});

// SIGNUP
router.post('/signup', noLogeado, passport.authenticate('local.signup', {
    successRedirect: '/perfil',
    failureRedirect: '/',
    failureFlash: true
}));

// SINGIN
router.get('/signin', noLogeado, (req, res) => {
    res.render('auth/signin');
});

router.post('/signin', noLogeado,  (req, res, next) => {
    passport.authenticate('local.signin', {
        successRedirect: '/perfil',
        failureRedirect: '/',
        failureFlash: true
    })(req, res, next);
});

router.get('/perfil', estaLogeado, (req, res) => {
    res.render('perfil');
});

router.get('/logout', estaLogeado, (req, res) => {
    req.logOut();
    res.redirect('/');
})

module.exports = router;
module.exports = {

    database: {
        host: 'localhost',
        user: 'root',
        password: '10313577',
        database: 'matriculas'
    }
};